#!/bin/bash

# Set Kafka home directory and broker address
KAFKA_HOME="${KAFKA_HOME:-/opt/kafka/kafka}"
BROKER_ADDRESS="${BROKER_ADDRESS:-localhost:9092}"

# Fetch all consumer groups
CONSUMER_GROUPS=$(${KAFKA_HOME}/bin/kafka-consumer-groups.sh --bootstrap-server $BROKER_ADDRESS --list 2>/dev/null)

# Check if any consumer groups are present
if [ -z "$CONSUMER_GROUPS" ]; then
  echo "No consumer groups found."
  exit 0
fi

# Define the output file
OUTPUT_FILE="lag_output.txt"

# Print header
printf "%-40s %-40s %-10s\n" "GROUP" "TOPIC" "LAG" > $OUTPUT_FILE

# Loop through each consumer group and fetch lag details
for GROUP in $CONSUMER_GROUPS; do
  ${KAFKA_HOME}/bin/kafka-consumer-groups.sh --bootstrap-server $BROKER_ADDRESS --describe --group $GROUP 2>/dev/null | \
  awk -v group="$GROUP" '
  BEGIN { FS="[[:space:]]+" }
  NR > 1 && $1 != "TOPIC" && $1 != "GROUP" {
    if ($6 != "-" && $6 != "" && $6 > 1000)
      printf "%-40s %-40s %-10s\n", group, $1, $6
  }' >> $OUTPUT_FILE
done

echo "Output saved to $OUTPUT_FILE"
