# Terraform for Azure

This repository contains Terraform configuration files to deploy and manage Azure resources. The configurations are designed to be modular and reusable for different environments.

## Quick Start Guide

### Prerequisites

- Install [Terraform](https://www.terraform.io/downloads.html) v1.0.0 or higher.
- Install [Azure CLI](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli) for authentication.
- Ensure you have an Azure subscription with the necessary permissions.

### Getting Started

1. **Authentication:**
   - Log in to Azure using the Azure CLI:
     ```bash
     az login
     ```

2. **Initialize Terraform:**
   - Navigate to your desired environment directory and initialize Terraform: Example
     ```bash
     cd environments/dev
     terraform init
     ```

3. **Review and Apply Changes:**
   - Review the planned changes:
     ```bash
     terraform plan
     ```
   - Apply the changes:
     ```bash
     terraform apply
     ```

### Usage

You can deploy Azure resources using Terraform by running the following commands:

```bash
cd environments/dev
terraform init
terraform apply
