**Converting Azure Kubernetes Service (AKS) cluster to Terraform state:**

The main purposes for doing this include:
Converting an existing Azure Kubernetes Service (AKS) cluster to Terraform state involves importing the existing resources into Terraform's state file without making any changes to those resources. This is useful for managing and maintaining the AKS cluster using Terraform going forward.

**Infrastructure as Code (IaC):** Transition the management of your existing AKS cluster and its associated resources (like node pools, network components, etc.) into Terraform, enabling consistent and repeatable infrastructure deployments.

**Centralized Management:** Consolidate infrastructure management under Terraform, reducing the risk of configuration drift and ensuring that all changes to the AKS cluster are tracked in version control.

**Enhanced Collaboration:** With the AKS cluster managed in Terraform, teams can collaborate more effectively, using pull requests and reviews to manage infrastructure changes.

**Automated Provisioning:** Leverage Terraform’s capabilities to automate not just the initial provisioning but also updates and scaling operations of the AKS cluster and related resources.

**Disaster Recovery:** By managing your AKS cluster in Terraform, you can easily recreate the infrastructure in another region or environment in case of a disaster.

**Steps to Azure Kubernetes Service (AKS) cluster to Terraform State:**

**1) Prepare the Terraform Configuration:**

Define the (AKS) cluster configuration in your Terraform files, matching the current setup of your existing (AKS) cluster.

**2) Import the AKS into Terraform( Updated the required values in the commands before run):**

#Importing the Resource Group

  terraform import azurerm_resource_group.rg /subscriptions/<--subscriptions-->/resourceGroups/<--resourceGroupName-->

#Importing the Virtual Network

  terraform import azurerm_virtual_network.virtual_network /subscriptions/<--subscriptions-->/resourceGroups/<--resourceGroupName-->/providers/Microsoft.Network/virtualNetworks/<--virtualNetworkName-->

#Importing the Virtual Subnet

  terraform import azurerm_subnet.virtual_subnet /subscriptions/<--subscriptions-->/resourceGroups/<--resourceGroupName-->/providers/Microsoft.Network/virtualNetworks/<--virtualNetworkName-->/subnets/<--SubnetName-->

#Importing the AKS Cluster

  terraform import azurerm_kubernetes_cluster.aks /subscriptions/<--subscriptions-->/resourceGroups/<--resourceGroupName-->/providers/Microsoft.ContainerService/managedClusters/<--AKs Cluster Name-->

#Importing the Multiple NodePools

Example:-
terraform import azurerm_kubernetes_cluster_node_pool.node_pool_1 /subscriptions/<--subscriptions-->/resourceGroups/<--resourceGroupName-->/providers/Microsoft.ContainerService/managedClusters/<--aks cluster name-->/agentPools/<--nodepoolname-->

Example:-
terraform import azurerm_kubernetes_cluster_node_pool.node_pool_2 /subscriptions/<--subscriptions-->/resourceGroups/<--resourceGroupName-->/providers/Microsoft.ContainerService/managedClusters/<--aks cluster name-->/agentPools/<--nodepoolname-->

**3) Run terraform plan:**

After importing, run terraform plan to review the differences between the imported state and the configuration defined in your Terraform files. Make necessary adjustments to ensure they match.

**4) Apply Configuration:**
Once the configuration is accurate, use terraform apply to apply any necessary changes to bring the infrastructure in line with the Terraform state.
