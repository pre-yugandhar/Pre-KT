# Converting Manually Created Azure Resources to Terraform State

## Introduction

This document provides a step-by-step guide to importing manually created Azure resources into Terraform's state file. By doing so, you can manage these resources using Terraform, enabling consistent and automated infrastructure management.

## Prerequisites

Before starting the conversion process, ensure that you have the following:

- **Terraform** installed and configured. [Terraform Installation Guide](https://learn.hashicorp.com/tutorials/terraform/install-cli)
- **Azure CLI** installed and authenticated to your Azure account. [Azure CLI Installation Guide](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli)
- **Access permissions** to the Azure resources you intend to import.
- **Terraform configuration files** (`.tf` files) set up in your working directory.

## Steps to Convert Resources

### 1. Identify Resources to Import

Start by identifying the Azure resources that have been manually created and need to be imported into Terraform. Some common resource types include:

- Virtual Machines (VMs)
- Managed Disks
- Network Interfaces
- Public IP Addresses
- Resource Groups
- Virtual Networks (VNets) and Subnets

### 2. Write Terraform Configuration, Import Resources, and Manage State

For each resource you plan to import, you need to:

1. **Write Terraform Configuration**: Define the resource in your `.tf` file. For example, to import a VM, you would write:

    ```hcl
    resource "azurerm_virtual_machine" "example_vm" {
      name                  = "my-vm"
      location              = "centralindia"
      resource_group_name   = "my-resource-group"
      network_interface_ids = [azurerm_network_interface.example_nic.id]
      vm_size               = "Standard_D2s_v3"

      storage_os_disk {
        name              = "my-os-disk"
        caching           = "ReadWrite"
        managed_disk_type = "Standard_LRS"
        disk_size_gb      = 30
      }

      os_profile {
        computer_name  = "my-vm"
        admin_username = "adminuser"
        admin_password = "Password123!"
      }

      os_profile_linux_config {
        disable_password_authentication = false
      }
    }
    ```

2. **Import the Resource into Terraform State**: Use the `terraform import` command to import the existing resource into your Terraform state. The syntax is:

    ```bash
    terraform import <RESOURCE_TYPE>.<NAME> <RESOURCE_ID>
    ```

    For example, to import the VM defined above:

    ```bash
    terraform import azurerm_virtual_machine.example_vm /subscriptions/<SUBSCRIPTION_ID>/resourceGroups/my-resource-group/providers/Microsoft.Compute/virtualMachines/my-vm
    ```

    Repeat this process for all resources you need to import.

3. **Validate the Import**: After importing, run the following command to ensure that your Terraform state and configuration are in sync:

    ```bash
    terraform plan
    ```

    This command shows the planned changes. Ideally, it should show no changes, indicating that the imported resources match the configuration.

4. **Manage Terraform State and Commit Changes**: Ensure your Terraform state file is stored securely, especially if you're working in a team environment. Consider using a remote backend (e.g., Azure Storage, S3) for shared state management. Once the resources have been successfully imported and validated, commit your Terraform configuration files to your version control system (e.g., Git):

    ```bash
    git add .
    git commit -m "Imported manually created Azure resources into Terraform"
    git push origin main
    ```

## Best Practices

- **Keep State Files Secure**: Store your Terraform state file in a secure, remote backend if you're collaborating with a team.
- **Regular Backups**: Regularly backup your Terraform state file to avoid losing track of managed resources.
- **Document Everything**: Maintain detailed documentation for any manual changes made to the infrastructure, especially if not managed through Terraform.

## Troubleshooting

### Common Issues

- **Resource Not Found**: Ensure that the resource ID provided during import is correct.
- **State Mismatch**: If the `terraform plan` command shows unexpected changes, double-check your Terraform configuration to ensure it matches the actual resource configuration.
- **Access Denied**: Make sure your Azure account has the necessary permissions to access and manage the resources.

## Conclusion

By following this guide, you can effectively bring manually created Azure resources under Terraform management, ensuring a consistent, automated, and version-controlled approach to infrastructure management.
