**Converting an existing VM to Terraform state:**

The main purposes for doing this include:
Infrastructure as Code: By managing the VM with Terraform, you can version control its configuration. This practice promotes reproducibility, consistency, and collaboration in managing infrastructure.

**Automation:** Terraform allows you to automate the provisioning and management of your infrastructure. This reduces manual efforts and the potential for human error.

**Consistency:** By importing the VM into Terraform, you ensure that the infrastructure configuration is consistent with the desired state defined in your Terraform files. This helps in maintaining uniformity across environments.

**Scalability:** Managing infrastructure with Terraform makes it easier to scale resources up or down based on your needs. You can replicate configurations for new VMs or other resources quickly.

**Audit and Compliance:** Using Terraform, you can track changes to your infrastructure over time. This aids in auditing and ensures compliance with organizational policies and standards.

**Disaster Recovery:** Terraform configurations can be used to recreate your infrastructure in case of a disaster. This ensures that you can recover quickly with minimal downtime.

**Steps to Convert an Existing VM to Terraform State:**

**1) Prepare the Terraform Configuration:**

Define the VM's configuration in your Terraform files, matching the current setup of your existing VM.

**2) Import the VM into Terraform( Updated the required values in the commands before run):**

#Importing the Resource Group

  terraform import azurerm_resource_group.resource_group /subscriptions/<--subscriptions-->/resourceGroups/<--resourceGroupName-->

#Importing the Virtual Network

  terraform import azurerm_virtual_network.virtual_network /subscriptions/<--subscriptions-->/resourceGroups/<--resourceGroupName-->/providers/Microsoft.Network/virtualNetworks/<--virtualNetworkName-->

#Importing the Virtual Subnet

  terraform import azurerm_subnet.virtual_subnet /subscriptions/<--subscriptions-->/resourceGroups/<--resourceGroupName-->/providers/Microsoft.Network/virtualNetworks/<--virtualNetworkName-->/subnets/<--SubnetName-->

#Importing the Virtual network_interface

  terraform import azurerm_network_interface.network_interface /subscriptions/<--subscriptions-->/resourceGroups/<--resourceGroupName-->/providers/Microsoft.Network/networkInterfaces/<--VirtualnetworkinterfaceName-->

#Importing the OS Disk

  terraform import azurerm_managed_disk.os_disk /subscriptions/<--subscriptions-->/resourceGroups/<--resourceGroupName-->/providers/Microsoft.Compute/disks/<--OS Disk Name-->

#Importing the DATA Disk

  terraform import azurerm_managed_disk.data_disk /subscriptions/<--subscriptions-->/resourceGroups/<--resourceGroupName-->/providers/Microsoft.Compute/disks/<--DATA Disk Name-->

#Importing the Virtual Machine

  terraform import azurerm_virtual_machine.vm /subscriptions/<--subscriptions-->/resourceGroups/<--resourceGroupName-->/providers/Microsoft.Compute/virtualMachines/<--Vm Name-->

**3) Run terraform plan:**

After importing, run terraform plan to review the differences between the imported state and the configuration defined in your Terraform files. Make necessary adjustments to ensure they match.

**4) Apply Configuration:**
Once the configuration is accurate, use terraform apply to apply any necessary changes to bring the infrastructure in line with the Terraform state.
