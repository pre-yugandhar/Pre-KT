# Reusable Terraform Script for Creating Azure Linux Virtual Machines

This repository provides a reusable Terraform script to create an Azure Linux Virtual Machine (VM). The script is modular, parameterized, and customizable for various environments and requirements.

## Prerequisites

- [Terraform](https://www.terraform.io/downloads.html) installed on your local machine.
- An active Azure subscription.
- Azure CLI installed and authenticated (`az login`).

## Files Structure

- **`main.tf`**: Contains the main Terraform configuration for creating the resource group, virtual network, subnet, and VM.
- **`variables.tf`**: Defines input variables for the script.

## Usage

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd <repository-directory>
2. **Initialize Terraform**: Initialize Terraform to download the required providers and set up the workspace.
    ```bash
    terraform init
3. **Plan the deployment**: Review the planned deployment to ensure it matches your expectations.
   ```bash
   terraform plan
4. **Apply the deployment**: Apply the Terraform plan to create the Azure resources.
    ```bash
   terraform apply